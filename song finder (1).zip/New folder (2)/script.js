/**
 * Searches for an exact match on song + artist via Lyrics.ovh suggest endpoint,
 * then displays that track (with preview) for which you can fetch lyrics.
 */
async function searchSongs() {
    const song   = document.getElementById('songInput').value.trim();
    const artist = document.getElementById('artistInput').value.trim();
    const resultsList  = document.getElementById('resultsList');
    const lyricsDisplay = document.getElementById('lyricsDisplay');
  
    lyricsDisplay.innerHTML = '<p>Select a song above to view lyrics.</p>';
  
    if (!song || !artist) {
      resultsList.innerHTML = '<li>❗ Please enter both song name and artist name.</li>';
      return;
    }
  
    resultsList.innerHTML = '<li>🔍 Searching for exact match…</li>';
    const query = encodeURIComponent(`${song} ${artist}`);
  
    try {
      const res  = await fetch(`https://api.lyrics.ovh/suggest/${query}`);
      if (!res.ok) throw new Error(`Search failed (${res.status})`);
      const data = await res.json();
  
      // Filter for exact title & artist match
      const tracks = data.data.filter(t =>
        t.title.toLowerCase()  === song.toLowerCase() &&
        t.artist.name.toLowerCase() === artist.toLowerCase()
      );
  
      if (tracks.length === 0) {
        resultsList.innerHTML = '<li>No exact match found. Check spelling?</li>';
        return;
      }
  
      // Render the matching track(s)
      resultsList.innerHTML = tracks.map(track => {
        const cleanArtist = track.artist.name.replace(/'/g, "\\'");
        const cleanTitle  = track.title.replace(/'/g, "\\'");
        return `
          <li onclick="getLyrics('${cleanArtist}','${cleanTitle}')">
            <div style="display:flex; align-items:center; gap:10px;">
              <img src="${track.album.cover_small}" width="50" style="border-radius:4px;" />
              <div>
                <strong>${track.title}</strong><br/>
                <em>${track.artist.name}</em><br/>
                <audio src="${track.preview}" controls style="width:150px; margin-top:5px;"></audio>
              </div>
            </div>
          </li>`;
      }).join('');
  
    } catch (err) {
      console.error(err);
      resultsList.innerHTML = '<li>🚫 Error fetching songs. Please try again later.</li>';
    }
  }
  
  
  /**
   * Fetches full lyrics from Lyrics.ovh and displays them.
   */
  async function getLyrics(artist, title) {
    const lyricsDisplay = document.getElementById('lyricsDisplay');
    lyricsDisplay.innerHTML = `<p>🔍 Loading lyrics for <strong>${title}</strong> by <strong>${artist}</strong>…</p>`;
  
    try {
      const url = `https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`Lyrics not found (${res.status})`);
      const data = await res.json();
  
      if (data.lyrics && data.lyrics.trim()) {
        lyricsDisplay.innerHTML = `
          <h2>${title} — ${artist}</h2>
          <pre style="white-space:pre-wrap; line-height:1.5;">${data.lyrics}</pre>
        `;
      } else {
        lyricsDisplay.innerHTML = `<p>❌ No lyrics found for <strong>${title}</strong> by <strong>${artist}</strong>.</p>`;
      }
    } catch (err) {
      console.error(err);
      lyricsDisplay.innerHTML = `<p>⚠️ Couldn’t load lyrics for <strong>${title}</strong> by <strong>${artist}</strong>. Try checking the spelling.</p>`;
    }
  }
  